### Hexlet tests and linter status:
[![Actions Status](https://github.com/ohalivka/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/ohalivka/python-project-lvl1/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/bf8e8600f8b424860af8/maintainability)](https://codeclimate.com/github/ohalivka/python-project-lvl1/maintainability)

/var/folders/0n/vlwlz9fj5bj7j8fgp4g84mlm0000gn/T/tmpyxdf2j8d-ascii.cast

/var/folders/0n/vlwlz9fj5bj7j8fgp4g84mlm0000gn/T/tmp3vu7u8b8-ascii.cast
